package aporte1.juniorloor.facci.aporte1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView valor;
    Button convertir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        valor = (TextView) findViewById(R.id.tvLibra);
        convertir = (Button)findViewById(R.id.btnConvertir);


        convertir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);

                Bundle bundle = new Bundle();

                bundle.putString("dato",valor.getText().toString());

                intent.putExtras(bundle);
                startActivity(intent);

                valor.setText("");
            }
        });


    }
}
