package aporte1.juniorloor.facci.aporte1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        resultado= (TextView)findViewById(R.id.tvresultado);

        Bundle bundle = this.getIntent().getExtras();

        String result;
        double libra;
        libra = 453.592 ;
        double gramo;
        gramo = Integer.parseInt(bundle.getString( "dato"));

        result = String.valueOf((libra*gramo));

        resultado.setText(result+ " gramos");

        Toast.makeText(getApplicationContext(),"Regrese a la pantalla anterior para otra convesión", Toast.LENGTH_LONG).show();


    }


}
